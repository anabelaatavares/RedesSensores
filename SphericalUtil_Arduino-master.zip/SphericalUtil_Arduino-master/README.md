# SphericalUtil_Arduino
Small aproach to Google Maps Spherical Utils library but translated to arduino, currently support only some of the methods but will improve to support majority.  
Current version methods:  
* Distance between two coordiantes on earth.
* Compute positions with specific offsets from another one.
  
*Any contribution is welcomed.*
